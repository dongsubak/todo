import React, { Component } from 'react';
import classNames from 'classnames';
import Utils from './utils';

class TodoModel {

	constructor (key) {

		this.key = key;
		this.todos = Utils.store(key);
		this.onChanges = [];


/*		this.subscribe = this.subscribe.bind(this);
		this.inform = this.inform.bind(this);
		this.addTodo = this.addTodo.bind(this);
		this.toggleAll = this.toggleAll.bind(this);
		this.toggle = this.toggle.bind(this);
		this.destroy = this.destroy.bind(this);
		this.save = this.save.bind(this);
		this.clearCompleted = this.clearCompleted.bind(this);
		*/
	}

	subscribe (onChange) {
		this.onChanges.push(onChange);
	}

	inform () {
		Utils.store(this.key, this.todos);
		console.log('inform');
		this.onChanges.forEach(cb => cb());
	}

	addTodo (title) {
		this.todos = this.todos.concat({
			id: Utils.uuid(),
			title: title,
			completed: false
		});

		this.inform();
	}

	toggleAll (checked) {
		this.todos = this.todos.map(todo => {
			return Utils.extend({}, todo, {completed: checked});
		});

		this.inform();
	}

	toggle (todoToToggle) {
		this.todos = this.todos.map(todo => {
			return (todo !==todoToToggle ?
				todo :
				Utils.extend({}, todo, {completed: !todo.completed}))
		});

		this.inform();
	}

	destroy (todo) {
		this.todos = this.todos.filter(candidate => {
			return candidate !== todo;
		});

		this.inform();
	}

	save (todoToSave, text) {
		this.todos = this.todos.map(todo => {
			return todo !== todoToSave ? todo : Utils.extend({}, todo, {title: text});
		});

		this.inform();
	}

	clearCompleted () {
		this.todos = this.todos.filter(todo => {
			return !todo.completed;
		})

		this.inform();
	}

	render() {
		return (
			<li className={classNames({
				completed: this.props.todo.completed,
				editing: this.props.editing
			})}>
				<div className="view">
					<input
						className="toggle"
						type="checkbox"
						checked={this.props.todo.completed}
						onChange={this.props.onToggle}
					/>
					<label onDoubleClick={this.handleEdit}>
						{this.props.todo.title}
					</label>
					<button className="destroy" onClick={this.props.onDestroy} />
				</div>
				<input
					ref="editField"
					className="edit"
					value={this.state.editText}
					onBlur={this.handleSubmit}
					onChange={this.handleChange}
					onKeyDown={this.handleKeyDown}
				/>
			</li>
		);
	}
}

export default TodoModel;
